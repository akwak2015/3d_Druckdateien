                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2847201
WordClock 235 by Strippe is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Dies ist meine erste WordClock. Einfach und ohne Extras.
Gefunden habe ich den Plan bei
 http://www.instructables.com/id/Und-noch-eine-Wordclock/ .
Sie läuft mit einem Arduino NANO und einem RTC DS3231.
Der Ramen ist ein IKEA RIBBA 23 cmx23 cm. 
https://www.ikea.com/de/de/catalog/products/40378401/
Das WordClock Raster ist 217 mm x 217 mm und passt in den IKEA Ramen.
Da mein Drucker nur 220 mm kann, habe ich Bulid Plate Adhesion weg gelassen.
Zur Sicherheit habe ich den Rand vom Druckbett mit Kapton-Tape beklebt.
Die LED sind WS2812B-Smart-led-pixel-strip AliExpress mit 74Stück/m IP30.
Die Frontplatte wird auf 235 mm gezoomt. So passt Sie in das Raster mit 74LED/m .
In meinen Bildern stimmt das Raster noch nicht, ist aber geändert.
Die Datei Front_HowtoInkScape.pdf zeigt, wie man eine Frontplatte selbst erstellen kann
zum Beispiel für andere Sprachen. (leider nur in deutsch)

This is my first WordClock. Simple and without extras.
I found the plan at
 http://www.instructables.com/id/Und-noch-eine-Wordclock/ .
It runs on an Arduino NANO and a RTC DS3231.
Der Ramen ist ein IKEA RIBBA 23 cmx23 cm. 
https://www.ikea.com/de/de/catalog/products/40378401/
The WordClock grid is 217 mm x 217 mm and fits in the IKEA Ramen.
The LED's are WS2812B smart led pixel strip from AliExpress with 74pcs / m IP30.
The front panel is zoomed to 235 mm.
How to fit in the grid with 74LED / m.
Since my printer can only reach 220mm, I switch out Build Plate Adhesion.
The file Front How to InkScape.pdf shows how to create a front panel yourself
for example for other languages. (sadly only in German)
Sorry the english. Is google.



# Print Settings

Printer: Anet A8
Resolution: 0.2
Infill: 35%