                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3047658
Project CODE CRYPTEX WITH MAZEBOX by Hiob is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

If you download or collect one of my designs, please give me a like!

------------------------------------------------------------------------------------------------------------------------

Deutsch:

Auf Wunsch stelle ich hier mein Projekt "CODE CRYPTEX WITH MAZEBOX" zur Verfügung!
Warum so viele (stl-Dateien)??? Weil ich die unterschiedlichsten Möglichkeiten erarbeitet habe und diese gerne zur Verfügung stelle... sucht euch die für euch passende aus!
Die urpsrüngliche "Da Vinci Code Cryptex" war mir von der Passgenauigkeit zu ungenau... an allen Ecken und Enden klemmte es und nur eine Feile konnte Abhilfe Schaffen... darum gibt es nun 6 unterschiedlich große "Inner Rings"... die sich der Größe des CODE CRYPTEX optimal anpassen!

Version 1: Nur die äußeren Kanten des Cryptex sind abgeschrägt!
Version 2: Zwischen den einzelnen Ringen ist ein Grat!
Version 3: Zwischen den einzelnen Ringen und den Zahlen ist ein Grat!

Falls jemand eine tolle Idee für Zahlen oder Symbole hat... einfach her damit... versuche es gerne umzusetzen... falls ich Zeit dafür habe!

Weiteres Zubehör bzw. Abwandlungen für dieses Projekt findet ihr hier:

Double-Maze:
https://www.thingiverse.com/thing:3060249

Top:
https://www.thingiverse.com/thing:3065181

Glasdome:
https://www.thingiverse.com/thing:3050475

Ständer Version 1:
https://www.thingiverse.com/thing:3050489

StarWars-Ständer:
https://www.thingiverse.com/thing:3059674

Würfelaugen:
https://www.thingiverse.com/thing:3050486

Predator-Zahlen:
https://www.thingiverse.com/thing:3050496

StarWars-Zahlen (Imperium):
https://www.thingiverse.com/thing:3050499

Runen:
https://www.thingiverse.com/thing:3055310

Barcode:
https://www.thingiverse.com/thing:3056166

Digitale Zahlen:
https://www.thingiverse.com/thing:3056964

Dalek-Zahlen:
https://www.thingiverse.com/thing:3057357

Jokerman-Zahlen:
https://www.thingiverse.com/thing:3058682

WyvernWings-Zahlen:
https://www.thingiverse.com/thing:3058848

Phantom-Zahlen:
https://www.thingiverse.com/thing:3059191

Propanic-Zahlen:
https://www.thingiverse.com/thing:3059445

Bambora-Zahlen:
https://www.thingiverse.com/thing:3060240

Y2Kill-Zahlen:
https://www.thingiverse.com/thing:3060871

Braille-Zahlen (Blindenschrift):
https://www.thingiverse.com/thing:3063857

Blanco-Zahlen (zur Selbstgestaltung):
https://www.thingiverse.com/thing:3050505

Sparbüchse:
https://www.thingiverse.com/thing:3076477

-------------------------------------------------------------------------------------------------------------------

English:

Upon request, I make my project "CODE CRYPTEX WITH MAZEBOX" available here! Why so many (stl files) ??? Because I have worked out the different possibilities and like to make them available ... choose the right one for you!
The original "Da Vinci Code Cryptex" was too inaccurate for me because of the accuracy of the fit ... it jammed at every turn and only a file could solve it ... that's why there are now 6 differently sized "Inner Rings" ... the to adapt optimally to the size of the CODE CRYPTEX!

Version 1: Only the outer edges of the Cryptex are bevelled! 
Version 2: Between the individual rings is a ridge! 
Version 3: Between the individual rings and the numbers is a ridge!

If someone has a great idea for numbers or symbols ... just let me try it ... if I have the time!

Further accessories and modifications for this project can be found here:

Double-Maze:
https://www.thingiverse.com/thing:3060249

Top:
https://www.thingiverse.com/thing:3065181

Glass Dome:
https://www.thingiverse.com/thing:3050475

Stand Version 1:
https://www.thingiverse.com/thing:3050489

StarWars-Stand:
https://www.thingiverse.com/thing:3059674

Dice-Eyes:
https://www.thingiverse.com/thing:3050486

Predator-Numbers:
https://www.thingiverse.com/thing:3050496

StarWars-Numbers (imperial):
https://www.thingiverse.com/thing:3050499

Runes:
https://www.thingiverse.com/thing:3055310

Barcode:
https://www.thingiverse.com/thing:3056166

Digital-Numbers:
https://www.thingiverse.com/thing:3056964

Dalek-Numbers:
https://www.thingiverse.com/thing:3057357

Jokerman-Numbers:
https://www.thingiverse.com/thing:3058682

WyvernWings-Numbers:
https://www.thingiverse.com/thing:3058848

Phantom-Numbers:
https://www.thingiverse.com/thing:3059191

Propanic-Numbers:
https://www.thingiverse.com/thing:3059445

Bambora-Numbers:
https://www.thingiverse.com/thing:3060240

Y2Kill-Numbers:
https://www.thingiverse.com/thing:3060871

Braille-Numbers:
https://www.thingiverse.com/thing:3063857

Blanco-Numbers (DIY):
https://www.thingiverse.com/thing:3050505

MoneyBox:
https://www.thingiverse.com/thing:3076477



# Print Settings

Printer: Anycubic I3 Mega
Rafts: No
Supports: No
Resolution: 0,2 mm
Infill: 20 %

Notes: 
Deutsch:

Bemalt bzw. behandelt habe ich meine Ausdrucke ganz einfach mit Metalic-Wachs (Rub'n Buff bzw. mit Wax Paste von Pentart)... einfach etwas Wachs auf die Fingerspitze getan und vorsichtig auf dem Druck verrieben... die Effekte kommen von selbst!

Der Inner_Ring_Size1 ist für den ersten Outer_Ring, der Inner_Ring_Size2 für den zweiten usw.!

------------------------------------------------------------------------------------------------------------------------

English:

I simply painted or treated my prints with Metalic wax (Rub'n Buff or Penta wax paste) ... just put some wax on the fingertip and rub gently on the print ... the effects come from even!

The Inner_Ring_Size1 is for the first Outer_Ring, the Inner_Ring_Size2 for the second, and so on!

# Post-Printing

## Variationen / Variations

Hier ein paar Bilder der unterschiedlichen möglichen Variationen!
Es werden im Laufe der Zeit immer mehr!!!

Here are some pictures of the different possible variations!
It will get more and more over time!!!


![Alt text](https://cdn.thingiverse.com/assets/81/7b/2e/76/a7/IMG_2912.jpg)
Double-Maze

![Alt text](https://cdn.thingiverse.com/assets/56/7c/92/0a/ca/IMG_2831.jpg)
Glasdome / Glassdome

![Alt text](https://cdn.thingiverse.com/assets/0c/9c/5f/fe/fc/IMG_2842_-_Kopie.jpg)
Ständer Version 1 / Stand Version 1

![Alt text](https://cdn.thingiverse.com/assets/d8/f8/d6/ce/2d/IMG_2906.jpg)
StarWars-Stand

![Alt text](https://cdn.thingiverse.com/assets/18/25/13/91/32/IMG_2879.jpg)
Würfelaugen / Dice-Eyes

![Alt text](https://cdn.thingiverse.com/assets/77/81/00/79/8b/IMG_2850.jpg)
Predator

![Alt text](https://cdn.thingiverse.com/assets/6e/fa/56/8b/2c/IMG_2852.jpg)
StarWars (Imperium)

![Alt text](https://cdn.thingiverse.com/assets/16/92/c9/f4/bf/IMG_2873.jpg)
Runen

![Alt text](https://cdn.thingiverse.com/assets/7a/dc/71/bb/e6/IMG_2877.jpg)
BarCode

![Alt text](https://cdn.thingiverse.com/assets/ba/f3/b6/52/83/IMG_2882.jpg)
Digital

![Alt text](https://cdn.thingiverse.com/assets/d9/07/c9/24/0f/IMG_2884.jpg)
Dalek

![Alt text](https://cdn.thingiverse.com/assets/86/33/56/b4/fa/IMG_2886.jpg)
Jokerman

![Alt text](https://cdn.thingiverse.com/assets/dc/ea/58/99/d3/IMG_2889.jpg)
WyvernWings

![Alt text](https://cdn.thingiverse.com/assets/54/38/15/ef/a4/IMG_2899.jpg)
Phantom

![Alt text](https://cdn.thingiverse.com/assets/24/f9/83/bc/64/IMG_2903.jpg)
Propanic

![Alt text](https://cdn.thingiverse.com/assets/40/b9/2f/c4/82/IMG_2918.jpg)
Bambora

![Alt text](https://cdn.thingiverse.com/assets/e9/f0/00/55/d8/IMG_2920.jpg)
Y2Kill

![Alt text](https://cdn.thingiverse.com/assets/17/84/6d/9f/0e/IMG_2925.jpg)
Braille (Blindenschrift)

![Alt text](https://cdn.thingiverse.com/assets/ff/a1/e0/84/e0/IMG_2928.jpg)
Top

![Alt text](https://cdn.thingiverse.com/assets/c6/f3/91/c2/1a/IMG_2974.jpg)
MoneyBox