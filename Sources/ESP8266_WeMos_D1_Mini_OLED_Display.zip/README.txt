                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3199505
ESP8266 WeMos D1 Mini OLED Display by acrobotic is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Files for printing a cute little enclosure for the WeMos D1 Mini development board for the ESP8266 and the OLED shield. This is part of a tutorial video for building a tiny desktop display:

https://youtu.be/H8C6cpVGLFU

We use the Arduino IDE to write code that allows fetching YouTube statistics for displaying the subscriber count of a channel. We use the flash memory of the ESP8266 to store the data and display the increase or decrease in subscriber count over the past 24-hour period.

# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator Mini
Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: 0.2mm
Infill: 10%
Filament_brand: 3D Solutech
Filament_color: Red
Filament_material: PLA