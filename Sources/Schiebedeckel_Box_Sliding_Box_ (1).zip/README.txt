                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3038259
Schiebedeckel Box (Sliding Box)  by Dr_Peacock is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Eine einfache Box um z.B. Kleinteile aufzubewahren.
Die Box hat einen Schiebedeckel. Dieser rastet am Ende und am Anfang ein. So kann sich der Deckel nicht von alleine öffnen. Eine Vertiefung an der Oberseite des Deckels erleichtert das Öffnen. 

Ich lade die Box in drei Größen hoch. 
40x30x15, 40x40x17 und 50x50x24 (Innenmaße)
Ihr könnt gerne eure Wünsche für andere Größen in die Comments schreiben. Ich versuche dann eure Wünsche zu erfüllen. Gebt bitte immer die gewünschten Innenmaße an. 

------------------
English:
I upload the box in three different sizes. 
40x30x15, 40x40x17 und 50x50x24 (inner dimensions)
You can leave a comment with your wishes for other sizes. i try to fulfill your wish. Please leave the desired inner dimensions for the box.


# Print Settings

Printer: BQ Prusa i3 Hephestos
Rafts: No
Supports: No
Resolution: 0.2
Infill: 17%

Notes: 
Es kann sein, dass man noch etwas nachschleifen oder feilen muss. Aber nur ein wenig, sonst ist der Deckel zu leichtgängig. 

-----------------------
English:
It may be possible that you have to grind or file the printed box. But only a little bit, otherwise the lid is too loose.